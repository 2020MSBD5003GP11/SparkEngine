const express = require('express');
const connectDB = require('./db/connectDB');
const path = require('path');
const createError = require('./api/utils/createResponseError');
const behaviorRoutes = require('./api/routes/behavior');

const app = express();

// Connect Database
connectDB();

app.enable('trust proxy'); // to allow access of req.ip
app.use(express.json({ extended: false }));
app.use('/api/', (req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header(
    'Access-Control-Allow-Headers',
    'Origin, X-Requested-With, Content-Type, Accept, Authorization'
  );
  if (req.method === 'OPTIONS') {
    res.header('Access-Control-Allow-Methods', 'PUT, POST, PATCH, DELETE, GET');
    return res.status(200).json({});
  }
  res.header('Cache-Control', 'no-cache, no-store, must-revalidate');
  next();
});

app.use('/api/behavior', behaviorRoutes);
// 404 for API
app.use('/api', (req, res, next) => {
  next(createError(404));
});

// Serve static assets in production
if (process.env.NODE_ENV === 'production') {
  // Set static folder
  app.use(express.static('client/build'));

  app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'client', 'build', 'index.html'));
  });
}

// Error handling
app.use((req, res, next) => {
  next(createError(404));
});
app.use((error, req, res, next) => {
  res.status(error.status || 500);
  if (Array.isArray(error.errors)) {
    return res.json({
      errors: error.errors,
    });
  }
  res.json({
    error: {
      message: error.message,
    },
  });
});

const serverPort = process.env.PORT || 5000;
app.listen(serverPort, () => {
  console.log(`Server started on PORT ${serverPort}`);
});
