import React, { useEffect, useState, useMemo, Fragment } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import { Grid, Paper, Typography } from '@material-ui/core';
import { makeStyles, useTheme } from '@material-ui/styles';
import {
  red,
  pink,
  deepPurple,
  blue,
  green,
  amber,
  deepOrange,
  grey,
} from '@material-ui/core/colors';
import {
  fetchDailyCounts,
  fetchEventTypeCounts,
  fetchTopBrandsCounts,
} from '../../../redux/actions/behavior';
import Translate from '../../lang/Translate';
import DatePicker from '../../widgets/DatePicker';
import { dateInServerTZToISOString, formatUtcToServerTZ } from '../../../utils/datetime';
import {
  ResponsiveContainer,
  LineChart,
  XAxis,
  YAxis,
  CartesianGrid,
  Line,
  Tooltip,
  PieChart,
  Pie,
  Legend,
  Cell,
  ComposedChart,
  Bar,
} from 'recharts';

const useStylesTooltip = makeStyles(theme => ({
  root: {
    padding: theme.spacing(1),
  },
}));

const CustomTooltip = ({ active, payload, label }) => {
  const classes = useStylesTooltip();
  if (active) {
    return <Paper className={classes.root}>{`${label} : ${payload[0].value}`}</Paper>;
  }
  return null;
};

const useStyles = makeStyles(theme => ({
  paper: {
    padding: theme.spacing(2),
  },
  chartSizeWrapper: {
    width: '100%',
    paddingTop: '100%',
    position: 'relative',
  },
  chartAbsWrapper: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
  },
}));

const minDate = dateInServerTZToISOString('2019-10-01');
const maxDate = dateInServerTZToISOString('2019-10-31');

const colors = [
  red[200],
  blue[200],
  green[200],
  deepPurple[200],
  amber[200],
  pink[200],
  deepOrange[200],
  grey[200],
];

const Dashboard = ({
  // state
  stateBehavior: {
    dailyCountsLoading,
    dailyCounts,
    eventTypeCountsLoading,
    eventTypeCounts,
    topBrandsCountsLoading,
    topBrandsCounts,
  },
  // actions
  fetchDailyCounts,
  fetchEventTypeCounts,
  fetchTopBrandsCounts,
}) => {
  const [fromDate, setFromDate] = useState(minDate);
  const [toDate, setToDate] = useState(maxDate);

  useEffect(() => {
    const from = formatUtcToServerTZ('yyyy-MM-dd', fromDate);
    const to = formatUtcToServerTZ('yyyy-MM-dd', toDate);
    fetchDailyCounts(from, to);
    fetchEventTypeCounts(from, to);
    fetchTopBrandsCounts(from, to);
  }, [fetchDailyCounts, fetchEventTypeCounts, fetchTopBrandsCounts, fromDate, toDate]);

  const pieData = useMemo(
    () =>
      Object.entries(eventTypeCounts || {}).map(([name, value]) => ({
        name,
        value,
      })),
    [eventTypeCounts]
  );

  const classes = useStyles();
  const theme = useTheme();

  return (
    <Grid container spacing={2}>
      <Grid item xs={6}>
        <DatePicker
          fullWidth
          label='FROM'
          value={fromDate}
          onChange={isoString => {
            setFromDate(isoString);
            if (isoString > toDate) {
              setToDate(isoString);
            }
          }}
          minDate={minDate}
          maxDate={maxDate}
        />
      </Grid>
      <Grid item xs={6}>
        <DatePicker
          fullWidth
          label='TO'
          value={toDate}
          onChange={isoString => setToDate(isoString)}
          minDate={fromDate}
          maxDate={maxDate}
        />
      </Grid>
      {!dailyCountsLoading &&
        dailyCounts instanceof Array &&
        dailyCounts.length > 0 &&
        !eventTypeCountsLoading &&
        eventTypeCounts instanceof Object &&
        !topBrandsCountsLoading &&
        topBrandsCounts instanceof Array &&
        topBrandsCounts.length > 0 && (
          <Fragment>
            <Grid item xs={12}>
              <Paper className={classes.paper}>
                <Typography variant='h6'>
                  <Translate msg='DAILY_TREND' />
                </Typography>
                <div className={classes.chartSizeWrapper} style={{ paddingTop: '400px' }}>
                  <div className={classes.chartAbsWrapper}>
                    <ResponsiveContainer>
                      <LineChart
                        data={dailyCounts}
                        margin={{ top: 20, right: 20, bottom: 20, left: 20 }}
                      >
                        <CartesianGrid stroke={theme.palette.divider} strokeDasharray='5 5' />
                        <YAxis dataKey='count' type='number' stroke={theme.palette.text.primary} />
                        <XAxis
                          dataKey='day'
                          stroke={theme.palette.text.primary}
                          type='category'
                          angle={-5}
                        />
                        <Tooltip content={<CustomTooltip />} />
                        <Line type='monotone' dataKey='count' stroke={theme.palette.primary.main} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </Paper>
            </Grid>
            <Grid item xs={12} lg={6}>
              <Paper className={classes.paper}>
                <Typography variant='h6'>
                  <Translate msg='EVENT_TYPES' />
                </Typography>
                <div className={classes.chartSizeWrapper} style={{ paddingTop: '400px' }}>
                  <div className={classes.chartAbsWrapper}>
                    <ResponsiveContainer>
                      <PieChart margin={{ top: 50, bottom: 50, left: 150, right: 150 }}>
                        <Pie
                          activeIndex={0}
                          // activeShape={renderActiveShape}
                          data={pieData}
                          innerRadius={'30%'}
                          outerRadius={'90%'}
                          nameKey='name'
                          dataKey='value'
                          label={({ value, percent }) =>
                            `${value} (${(percent * 100).toFixed(1)}%)`
                          }
                        >
                          {pieData.map((entry, idx) => (
                            <Cell key={idx} fill={colors[idx % colors.length]} />
                          ))}
                        </Pie>
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </Paper>
            </Grid>
            <Grid item xs={12} lg={6}>
              <Paper className={classes.paper}>
                <Typography variant='h6'>
                  <Translate msg='TOP_BRANDS' />
                </Typography>
                <div className={classes.chartSizeWrapper} style={{ paddingTop: '400px' }}>
                  <div className={classes.chartAbsWrapper}>
                    <ResponsiveContainer>
                      <ComposedChart
                        layout='vertical'
                        data={topBrandsCounts}
                        margin={{ top: 20, right: 20, bottom: 20, left: 20 }}
                      >
                        <CartesianGrid stroke={theme.palette.divider} strokeDasharray='5 5' />
                        <XAxis
                          dataKey='count'
                          type='number'
                          stroke={theme.palette.text.primary}
                          allowDecimals={false}
                        />
                        <YAxis
                          dataKey='brand'
                          stroke={theme.palette.text.primary}
                          type='category'
                          width={120}
                        />
                        <Tooltip content={<CustomTooltip />} />
                        <Bar dataKey='count' barSize={20} fill={theme.palette.primary.main} />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </Paper>
            </Grid>
          </Fragment>
        )}
    </Grid>
  );
};

Dashboard.propTypes = {
  // state
  stateBehavior: PropTypes.object.isRequired,
  // actions
  fetchDailyCounts: PropTypes.func.isRequired,
  fetchEventTypeCounts: PropTypes.func.isRequired,
  fetchTopBrandsCounts: PropTypes.func.isRequired,
};

const mapStateToProps = state => ({
  stateBehavior: state.behavior,
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      fetchDailyCounts,
      fetchEventTypeCounts,
      fetchTopBrandsCounts,
    },
    dispatch
  );

export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);
