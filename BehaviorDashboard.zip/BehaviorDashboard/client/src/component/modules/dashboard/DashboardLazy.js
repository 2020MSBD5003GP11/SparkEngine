import React, { lazy } from 'react';
import Suspense from '../../lazy/Suspense';

const LazyComponent = lazy(() => import('./Dashboard'));

export default () => {
  return <Suspense lazyComponent={<LazyComponent />} />;
};
