import React, { useMemo } from 'react';
import { ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import { deepPurple, lightBlue } from '@material-ui/core/colors';

const MyThemeProvider = ({ children }) => {
  const prefersDarkMode = true; //useMediaQuery('(prefers-color-scheme: dark)');

  const theme = useMemo(
    () =>
      createMuiTheme({
        palette: {
          type: prefersDarkMode ? 'dark' : 'light',
          primary: prefersDarkMode ? lightBlue : deepPurple,
        },
        // transitions: {
        //   duration: {
        //     enteringScreen: 2000,
        //     leavingScreen: 2000
        //   }
        // }
      }),
    [prefersDarkMode]
  );

  return <ThemeProvider theme={theme}>{children}</ThemeProvider>;
};

export default MyThemeProvider;
