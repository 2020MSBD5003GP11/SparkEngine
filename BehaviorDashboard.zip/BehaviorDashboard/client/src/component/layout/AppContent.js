import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import AuthorizedContent from './authorized/AuthorizedContent';
import Snackbars from './Snackbars';
import { SnackbarProvider } from 'notistack';
import { MuiPickersUtilsProvider } from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';

const useStyles = makeStyles(theme => ({
  appRoot: {
    backgroundColor: theme.palette.background.default,
    color: theme.palette.text.primary,
    display: 'flex',
    width: '100%',
    minHeight: '100%',
    minWidth: '320px',
  },
}));

const AppContent = props => {
  const classes = useStyles();
  return (
    <div className={classes.appRoot}>
      <MuiPickersUtilsProvider utils={DateFnsUtils}>
        <SnackbarProvider maxSnack={3}>
          <Snackbars />
          <AuthorizedContent />
        </SnackbarProvider>
      </MuiPickersUtilsProvider>
    </div>
  );
};

export default AppContent;
