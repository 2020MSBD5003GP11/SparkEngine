import React, { useEffect, useState, Fragment } from 'react';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
  Divider,
  Drawer,
  List,
  ListItem,
  ListItemText,
  Hidden,
  IconButton,
} from '@material-ui/core';
import { ChevronRight as ChevronRightIcon } from '@material-ui/icons';
import { makeStyles } from '@material-ui/core/styles';
import { togglePCMenuDrawer, toggleMBMenuDrawer } from '../../../redux/actions/ui';
import Translate from '../../lang/Translate';
import { Link } from 'react-router-dom';

const mbDrawerWidth = 240;
const pcDrawerEdgeBarWidth = 16;
const pcDrawerMenuWidth = 240;
const pcDrawerTooglePaddingWidth = 16;
const pcDrawerOpenedWidth = pcDrawerEdgeBarWidth + pcDrawerMenuWidth + pcDrawerTooglePaddingWidth;
const pcDrawerClosedWidth = pcDrawerEdgeBarWidth + pcDrawerTooglePaddingWidth;

const menuCollapseTimeout = 200;

const useStyles = makeStyles(theme => ({
  pcDrawer: {
    flexShrink: 0,
  },
  pcDrawerOpened: {
    width: pcDrawerOpenedWidth,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  pcDrawerClosed: {
    width: pcDrawerClosedWidth,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
  },
  mbDrawerPaper: {
    width: mbDrawerWidth,
  },
  pcDrawerPaper: {
    flexDirection: 'row',
    overflowX: 'hidden',
    borderRight: 'none',
  },
  pcDrawerEdgeBar: {
    width: pcDrawerEdgeBarWidth,
    height: '100%',
    backgroundColor: theme.palette.primary.main,
  },
  pcDrawerTooglePadding: {
    width: pcDrawerTooglePaddingWidth,
    height: '100%',
    backgroundColor: theme.palette.background.default,
    zIndex: -1,
  },
  pcMenuContainer: {
    overflowX: 'hidden',
    height: '100%',
    boxShadow: theme.shadows[2],
  },
  pcMenuContainerOpened: {
    overflowY: 'auto',
    width: pcDrawerMenuWidth,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  pcMenuContainerClosed: {
    overflowY: 'hidden',
    width: 0,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
  },
  pcMenu: {
    width: pcDrawerMenuWidth,
  },
  pcDrawerToggleBtn: {
    position: 'absolute',
    top: theme.spacing(1),
    right: pcDrawerTooglePaddingWidth,
    transform: 'translate(50%)',
    zIndex: theme.zIndex.drawer + 1,
    backgroundColor: `${theme.palette.background.paper} !important`,
    color: theme.palette.text.primary,
    border: '1px solid',
    borderColor: theme.palette.text.disabled,
    marginLeft: '-20px', // hotfix for skewing issue in IE
    transition: theme.transitions.create('opacity', {
      duration: 200,
    }),
  },
  pcDrawerToggleBtnHidden: {
    opacity: 0,
  },
  expandIconExpanded: {
    transform: 'rotate(180deg)',
    transition: theme.transitions.create('transform', {
      easing: theme.transitions.easing.sharp,
      duration: menuCollapseTimeout / 2,
    }),
  },
  expandIconCollapsed: {
    transform: 'rotate(0deg)',
    transition: theme.transitions.create('transform', {
      easing: theme.transitions.easing.sharp,
      duration: menuCollapseTimeout / 2,
    }),
  },
  nestedMenuItem: {
    paddingLeft: theme.spacing(4),
  },
}));

const MenuListItemText = ({ children }) => (
  <ListItemText primaryTypographyProps={{ noWrap: true }}>{children}</ListItemText>
);

const MenuDrawer = ({
  ui: { pcMenuDrawerOpened, mbMenuDrawerOpened },
  togglePCMenuDrawer,
  toggleMBMenuDrawer,
}) => {
  const classes = useStyles();
  const [mouseOnPCDrawer, setMouseOnPCDrawer] = useState(false);
  useEffect(() => {
    toggleMBMenuDrawer(false);
  }, [toggleMBMenuDrawer]);

  const drawerList = (
    <List disablePadding>
      <ListItem button component={Link} to='/'>
        <MenuListItemText>
          <Translate msg='PRODUCT_NAME' />
        </MenuListItemText>
      </ListItem>
      <Divider />
      <Divider />
    </List>
  );

  return (
    <Fragment>
      {/* The implementation can be swapped with js to avoid SEO duplication of links. */}
      <Hidden mdUp>
        {/* Mobile Drawer */}
        <Drawer
          variant='temporary'
          anchor='left'
          open={mbMenuDrawerOpened}
          onClose={() => toggleMBMenuDrawer(false)}
          classes={{
            paper: classes.mbDrawerPaper,
          }}
          ModalProps={{
            keepMounted: true, // Better open performance on mobile.
          }}
        >
          <div>{drawerList}</div>
        </Drawer>
      </Hidden>
      <Hidden smDown>
        {/* PC drawer */}
        <Drawer
          className={clsx(classes.pcDrawer, {
            [classes.pcDrawerOpened]: pcMenuDrawerOpened,
            [classes.pcDrawerClosed]: !pcMenuDrawerOpened,
          })}
          classes={{
            paper: clsx(classes.pcDrawerPaper, {
              [classes.pcDrawerOpened]: pcMenuDrawerOpened,
              [classes.pcDrawerClosed]: !pcMenuDrawerOpened,
            }),
          }}
          variant='permanent'
          open
          onMouseEnter={() => setMouseOnPCDrawer(true)}
          onMouseLeave={() => setMouseOnPCDrawer(false)}
        >
          <div className={classes.pcDrawerEdgeBar}></div>
          <div
            className={clsx(classes.pcMenuContainer, {
              [classes.pcMenuContainerOpened]: pcMenuDrawerOpened,
              [classes.pcMenuContainerClosed]: !pcMenuDrawerOpened,
            })}
          >
            <div className={classes.pcMenu}>{drawerList}</div>
          </div>
          <div className={classes.pcDrawerTooglePadding}></div>

          <IconButton
            size='small'
            className={clsx(classes.pcDrawerToggleBtn, {
              [classes.pcDrawerToggleBtnHidden]: pcMenuDrawerOpened && !mouseOnPCDrawer,
            })}
            onClick={() => togglePCMenuDrawer(!pcMenuDrawerOpened)}
          >
            <ChevronRightIcon
              className={clsx({
                [classes.expandIconExpanded]: pcMenuDrawerOpened,
                [classes.expandIconCollapsed]: !pcMenuDrawerOpened,
              })}
            />
          </IconButton>
        </Drawer>
      </Hidden>
    </Fragment>
  );
};

MenuDrawer.propTypes = {
  // states
  ui: PropTypes.object.isRequired,
  user: PropTypes.object,
  // actions
  togglePCMenuDrawer: PropTypes.func.isRequired,
  toggleMBMenuDrawer: PropTypes.func.isRequired,
};

const mapStateToProps = state => ({
  ui: state.ui,
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      togglePCMenuDrawer,
      toggleMBMenuDrawer,
    },
    dispatch
  );

export default connect(mapStateToProps, mapDispatchToProps)(MenuDrawer);
