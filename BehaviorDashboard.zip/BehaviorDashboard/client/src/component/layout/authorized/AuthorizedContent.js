import React, { Fragment } from 'react';
import { Route } from 'react-router-dom';
import AppBar from './AppBar';
import MenuDrawer from './MenuDrawer';
import MainContent from './MainContent';
import Routes from '../../routing/Routes';

const AuthorizedContent = () => {
  return (
    <Fragment>
      <AppBar />
      <MenuDrawer />
      <MainContent>
        <Route component={Routes} />
      </MainContent>
    </Fragment>
  );
};

export default AuthorizedContent;
