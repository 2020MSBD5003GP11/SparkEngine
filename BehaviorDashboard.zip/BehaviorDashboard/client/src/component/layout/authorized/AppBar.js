import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { AppBar, Toolbar, IconButton, Slide, useScrollTrigger } from '@material-ui/core';
import MenuIcon from '@material-ui/icons/Menu';
import { makeStyles } from '@material-ui/core/styles';
import { toggleMBMenuDrawer } from '../../../redux/actions/ui';

const HideOnScroll = ({ children }) => {
  const trigger = useScrollTrigger();
  return (
    <Slide appear={false} direction='down' in={!trigger}>
      {children}
    </Slide>
  );
};

const useStyles = makeStyles(theme => ({
  appBar: {
    transition: '200ms',
    [theme.breakpoints.up('md')]: {
      overflow: 'hidden',
      height: 0,
      minHeight: 0,
    },
  },
  menuButton: {
    marginRight: theme.spacing(2),
    [theme.breakpoints.up('md')]: {
      display: 'none',
    },
  },
}));

const MyAppBar = ({ toggleMBMenuDrawer }) => {
  const classes = useStyles();
  return (
    <HideOnScroll>
      <AppBar position='fixed' className={classes.appBar}>
        <Toolbar>
          <IconButton
            color='inherit'
            aria-label='open drawer'
            edge='start'
            onClick={() => toggleMBMenuDrawer(true)}
            className={classes.menuButton}
          >
            <MenuIcon />
          </IconButton>
        </Toolbar>
      </AppBar>
    </HideOnScroll>
  );
};

MyAppBar.propTypes = {
  // actions
  toggleMBMenuDrawer: PropTypes.func.isRequired,
};

const mapStateToProps = state => ({});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      toggleMBMenuDrawer,
    },
    dispatch
  );

export default connect(mapStateToProps, mapDispatchToProps)(MyAppBar);
