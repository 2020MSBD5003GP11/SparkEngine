import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { useSnackbar } from 'notistack';
import PropTypes from 'prop-types';
import { removeSnackbar } from '../../redux/actions/ui';
import { IconButton } from '@material-ui/core';
import { Close as CloseIcon } from '@material-ui/icons';
import translate from '../../lang';
import { vsprintf } from 'sprintf-js';

let displayed = [];
const storeDisplayed = id => {
  displayed = [...displayed, id];
};
const removeDisplayed = id => {
  displayed = [...displayed.filter(key => id !== key)];
};

const Snackbars = ({ snackbars, lang, removeSnackbar }) => {
  const { enqueueSnackbar, closeSnackbar } = useSnackbar();

  useEffect(() => {
    snackbars.forEach(({ message, msgArgs, options = {}, key }) => {
      const { dismissed, variant, translate: shouldTranslate, ...otherOptions } = options;
      if (dismissed) {
        // dismiss snackbar using notistack
        closeSnackbar(key);
        return;
      }

      // do nothing if snackbar is already displayed
      if (displayed.includes(key)) return;

      // display snackbar using notistack
      let outputMsg = shouldTranslate ? translate(message, lang) : message;
      if (msgArgs && msgArgs instanceof Array) {
        outputMsg = vsprintf(outputMsg, msgArgs);
      }
      enqueueSnackbar(outputMsg, {
        key,
        ...otherOptions,
        variant,
        action: key => (
          <IconButton size='small' onClick={() => closeSnackbar(key)}>
            <CloseIcon />
          </IconButton>
        ),
        onClose: (event, reason, myKey) => {
          if (options.onClose) {
            options.onClose(event, reason, myKey);
          }
        },
        onExited: (event, myKey) => {
          // removen this snackbar from redux store
          removeSnackbar(myKey);
          removeDisplayed(myKey);
        },
      });

      // keep track of snackbars that we've displayed
      storeDisplayed(key);
    });
  }, [snackbars, lang, closeSnackbar, enqueueSnackbar, removeSnackbar]);

  return null;
};

Snackbars.propTypes = {
  // state
  snackbars: PropTypes.array.isRequired,
  lang: PropTypes.string.isRequired,
  // actions
  removeSnackbar: PropTypes.func.isRequired,
};

const mapStateToProps = state => ({
  snackbars: state.ui.snackbars,
  lang: state.lang,
});

const mapDispatchToProps = dispatch => bindActionCreators({ removeSnackbar }, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(Snackbars);
