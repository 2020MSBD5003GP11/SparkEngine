import React, { Suspense, Component } from 'react';
import PropTypes from 'prop-types';
import LoadingOverlay from '../widgets/LoadingOverlay';

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    // Update state so the next render will show the fallback UI.
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    // You can also log the error to an error reporting service
    // logErrorToMyService(error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      // You can render any custom fallback UI
      return <p>Loading failed! Please reload the page.</p>;
    }

    return this.props.children;
  }
}

const MySuspense = ({ lazyComponent }) => {
  return (
    <ErrorBoundary>
      <Suspense fallback={<LoadingOverlay />}>{lazyComponent}</Suspense>
    </ErrorBoundary>
  );
};

MySuspense.propTypes = {
  lazyComponent: PropTypes.node.isRequired,
};

export default MySuspense;
