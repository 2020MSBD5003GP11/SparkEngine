import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { TextField } from '@material-ui/core';
import translate from '../../lang';

const TranslatedTextField = ({ label, helperText, lang, dispatch, ...rest }) => {
  return (
    <TextField
      {...rest}
      label={translate(label, lang)}
      helperText={helperText ? translate(helperText, lang) : undefined}
    />
  );
};

TranslatedTextField.propTypes = {
  label: PropTypes.string.isRequired,
  lang: PropTypes.string.isRequired,
};

const mapStateToProps = state => ({
  lang: state.lang,
});

export default connect(mapStateToProps)(TranslatedTextField);
