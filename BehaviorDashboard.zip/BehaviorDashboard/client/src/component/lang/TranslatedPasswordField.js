import React, { useState, useRef } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { TextField, InputAdornment, IconButton } from '@material-ui/core';
import { Visibility, VisibilityOff } from '@material-ui/icons';
import translate from '../../lang';

const TranslatedPasswordField = ({ label, helperText, lang, dispatch, ...rest }) => {
  const [showPassword, setShowPassword] = useState(false);
  const inputRef = useRef();

  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const preventDefaultEvent = e => {
    e.preventDefault();
  };

  return (
    <TextField
      {...rest}
      label={translate(label, lang)}
      helperText={helperText ? translate(helperText, lang) : undefined}
      type={showPassword ? 'text' : 'password'}
      inputRef={inputRef}
      InputProps={{
        endAdornment: (
          <InputAdornment position='end'>
            <IconButton
              aria-label='toggle password visibility'
              onClick={handleClickShowPassword}
              onMouseDown={preventDefaultEvent}
              onMouseUp={preventDefaultEvent}
            >
              {showPassword ? <Visibility /> : <VisibilityOff />}
            </IconButton>
          </InputAdornment>
        ),
      }}
    />
  );
};

TranslatedPasswordField.propTypes = {
  label: PropTypes.string.isRequired,
  lang: PropTypes.string.isRequired,
};

const mapStateToProps = state => ({
  lang: state.lang,
});

export default connect(mapStateToProps)(TranslatedPasswordField);
