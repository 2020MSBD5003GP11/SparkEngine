import React from 'react';
import { Button, CircularProgress } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';

const useStyles = makeStyles(theme => ({
  wrapper: {
    position: 'relative',
  },
  buttonProgress: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    margin: 'auto',
  },
}));

const ButtonWithLoading = ({
  className,
  children,
  loading,
  progressSize = 24,
  progressColor = 'primary',
  ...props
}) => {
  const classes = useStyles();
  return (
    <div className={[classes.wrapper, ...(className ? [className] : [])].join(' ')}>
      <Button {...props} disabled={loading}>
        {children}
      </Button>
      {loading && (
        <CircularProgress
          size={progressSize}
          className={classes.buttonProgress}
          color={progressColor}
        />
      )}
    </div>
  );
};

ButtonWithLoading.propTypes = {
  loading: PropTypes.bool.isRequired,
  progressSize: PropTypes.number,
  progressColor: PropTypes.oneOf(['primary', 'secondary', 'inherit']),
};

export default ButtonWithLoading;
