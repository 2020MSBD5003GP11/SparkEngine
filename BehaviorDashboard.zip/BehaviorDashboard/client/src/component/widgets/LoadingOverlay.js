import React from 'react';
import { CircularProgress } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles(theme => ({
  loadingOverlay: {
    zIndex: theme.zIndex.drawer + 1,
    color: '#fff',
    position: 'fixed',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    width: '100%',
    height: '100%',
    backgroundColor: 'rgba(0,0,0,0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    WebkitTapHighlightColor: 'transparent',
  },
}));

const LoadingOverlay = () => {
  const classes = useStyles();
  return (
    <div className={classes.loadingOverlay}>
      <CircularProgress color='inherit' size={60} />
    </div>
  );
};

export default LoadingOverlay;
