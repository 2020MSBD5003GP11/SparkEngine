import React from 'react';
import { connect } from 'react-redux';
import { utcToServerTZ, dateInServerTZToISOString } from '../../utils/datetime';
import PropTypes from 'prop-types';
import { DatePicker as MuiDatePicker } from '@material-ui/pickers';
import translate from '../../lang';

const CustomDatePicker = ({
  label,
  value,
  onChange,
  minDate,
  maxDate,
  format,
  lang,
  dispatch,
  ...rest
}) => (
  <MuiDatePicker
    {...rest}
    label={translate(label, lang)}
    value={value && utcToServerTZ(value)}
    onChange={date => {
      // set to start of day before callback
      if (date) {
        date.setHours(0);
        date.setMinutes(0);
        date.setSeconds(0);
      }
      onChange(dateInServerTZToISOString(date), rest);
    }}
    minDate={minDate && utcToServerTZ(minDate)}
    maxDate={maxDate && utcToServerTZ(maxDate)}
    format={format || 'yyyy/MM/dd'} // date format in input field
  />
);
CustomDatePicker.propTypes = {
  label: PropTypes.string.isRequired,
  value: PropTypes.string,
  onChange: PropTypes.func.isRequired,
  minDate: PropTypes.string,
  maxDate: PropTypes.string,
  format: PropTypes.string,
  lang: PropTypes.string.isRequired,
};
const mapStateToDatePickerProps = state => ({
  lang: state.lang,
});
export default connect(mapStateToDatePickerProps)(CustomDatePicker);

const CustomYearPicker = ({
  label,
  value,
  onChange,
  minYear,
  maxYear,
  format,
  lang,
  dispatch,
  ...rest
}) => (
  <MuiDatePicker
    {...rest}
    label={translate(label, lang)}
    value={value && new Date(value, 6, 1)}
    onChange={date => {
      if (date) {
        onChange(`${date.getFullYear()}`);
      } else {
        onChange(null);
      }
    }}
    minDate={minYear && new Date(minYear, 0, 1)}
    maxDate={maxYear && new Date(maxYear, 11, 31, 23, 59, 59, 999)}
    format={format || 'yyyy'} // date format in input field
    views={['year']}
  />
);
CustomYearPicker.propTypes = {
  label: PropTypes.string.isRequired,
  value: PropTypes.string,
  onChange: PropTypes.func.isRequired,
  minYear: PropTypes.string,
  maxYear: PropTypes.string,
  format: PropTypes.string,
  lang: PropTypes.string.isRequired,
};
const mapStateToYearPickerProps = state => ({
  lang: state.lang,
});
export const YearPicker = connect(mapStateToYearPickerProps)(CustomYearPicker);
