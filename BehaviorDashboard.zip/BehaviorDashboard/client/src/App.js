import React from 'react';
import './App.css';
import { Provider } from 'react-redux';
import store from './redux/store';
import { Router } from 'react-router-dom';
import CssBaseline from '@material-ui/core/CssBaseline';
import ThemeProvider from './component/layout/ThemeProvider';
import AppContent from './component/layout/AppContent';
import history from './utils/history';

const App = () => {
  return (
    <Provider store={store}>
      <Router history={history}>
        <CssBaseline />
        <ThemeProvider>
          <AppContent />
        </ThemeProvider>
      </Router>
    </Provider>
  );
};

export default App;
