import { utcToZonedTime, zonedTimeToUtc, format } from 'date-fns-tz';

const serverTimeZone = 'Asia/Hong_Kong';

export const utcToServerTZ = isoDate => {
  return utcToZonedTime(isoDate, serverTimeZone);
};

export const formatUtcToServerTZ = (dateFormat, isoDate, defaultVal = '-') => {
  return isoDate
    ? format(utcToServerTZ(isoDate), dateFormat, { timeZone: serverTimeZone })
    : defaultVal;
};

export const startOfDayInServerTZ = (date = new Date()) => {
  let ret = utcToServerTZ(date.toISOString());
  ret.setHours(0, 0, 0, 0);
  return ret;
};

export const dateInServerTZToISOString = date =>
  date ? zonedTimeToUtc(date, serverTimeZone).toISOString() : null;
