export const localStorageKeys = {
  LANG: 'lang',
  PC_MENU_DRAWER_EXPANDED: 'pc_menu_expanded',
};

export const supportedLang = {
  // ZH_HK: 'zh_hk',
  EN: 'en',
};
export const defaultLang = supportedLang.EN;
