import { combineEpics } from 'redux-observable';
import apiResponse from './apiResponse';
import behavior from './behavior';

export default combineEpics(apiResponse, behavior);
