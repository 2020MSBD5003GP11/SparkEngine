import { of, concat } from 'rxjs';
import { switchMap, map, catchError, mergeMap } from 'rxjs/operators';
import { combineEpics, ofType } from 'redux-observable';
import {
  FETCH_DAILY_COUNTS,
  FETCH_EVENT_TYPE_COUNTS,
  FETCH_TOP_BRANDS_COUNTS,
} from '../actionsTypes';
import {
  fetchDailyCountsSuccess,
  fetchDailyCountsFailure,
  fetchEventTypeCountsSuccess,
  fetchEventTypeCountsFailure,
  fetchTopBrandsCountsSuccess,
  fetchTopBrandsCountsFailure,
} from '../actions/behavior';
import { handleResponseError } from '../actions/apiResponse';

const fetchDailyCountsEpic = (action$, state$, { post }) =>
  action$.pipe(
    ofType(FETCH_DAILY_COUNTS),
    switchMap(action => {
      return post('/api/behavior/get_daily_trend', {
        from: action.payload.from,
        to: action.payload.to,
      }).pipe(
        map(res => res.response.data),
        mergeMap(data => of(fetchDailyCountsSuccess(data))),
        catchError(err => concat(of(handleResponseError(err)), of(fetchDailyCountsFailure())))
      );
    })
  );

const fetchEventTypeCountsEpic = (action$, state$, { post }) =>
  action$.pipe(
    ofType(FETCH_EVENT_TYPE_COUNTS),
    switchMap(action => {
      return post('/api/behavior/get_event_type_counts', {
        from: action.payload.from,
        to: action.payload.to,
      }).pipe(
        map(res => res.response.data),
        mergeMap(data => of(fetchEventTypeCountsSuccess(data))),
        catchError(err => concat(of(handleResponseError(err)), of(fetchEventTypeCountsFailure())))
      );
    })
  );

const fetchTopBrandsCountsEpic = (action$, state$, { post }) =>
  action$.pipe(
    ofType(FETCH_TOP_BRANDS_COUNTS),
    switchMap(action => {
      return post('/api/behavior/get_top_brands_counts', {
        from: action.payload.from,
        to: action.payload.to,
      }).pipe(
        map(res => res.response.data),
        mergeMap(data => of(fetchTopBrandsCountsSuccess(data))),
        catchError(err => concat(of(handleResponseError(err)), of(fetchTopBrandsCountsFailure())))
      );
    })
  );

export default combineEpics(
  fetchDailyCountsEpic,
  fetchEventTypeCountsEpic,
  fetchTopBrandsCountsEpic
);
