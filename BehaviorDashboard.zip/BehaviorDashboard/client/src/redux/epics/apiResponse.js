import { of, concat } from 'rxjs';
import { concatMap } from 'rxjs/operators';
import { combineEpics, ofType } from 'redux-observable';

import { HANDLE_RESPONSE_ERROR } from '../actionsTypes';
import { enqueueSnackbar } from '../actions/ui';

const handleResponseErrorDefaultOptions = {
  alert: true,
};

const handleResponseErrorEpic = action$ => {
  return action$.pipe(
    ofType(HANDLE_RESPONSE_ERROR),
    concatMap(action => {
      const { error, options } = action.payload;
      const mergedOptions = { ...handleResponseErrorDefaultOptions, ...(options || {}) };
      const { alert } = mergedOptions;
      let ret = [];
      if (
        alert &&
        error.response &&
        error.response.errors instanceof Array &&
        error.response.errors.length > 0
      ) {
        for (let err of error.response.errors) {
          if (err.message) {
            ret.push(of(enqueueSnackbar(`RES_ERR_${err.message}`)));
          }
        }
      } else {
        ret.push(of(enqueueSnackbar('API_UNKNOWN_ERROR')));
      }
      return concat(...ret);
    })
  );
};

export default combineEpics(handleResponseErrorEpic);
