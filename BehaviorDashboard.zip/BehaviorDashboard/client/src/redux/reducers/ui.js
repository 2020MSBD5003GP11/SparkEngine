import {
  TOGGLE_PC_MENU_DRAWER,
  TOGGLE_MB_MENU_DRAWER,
  ENQUEUE_SNACKBAR,
  CLOSE_SNACKBAR,
  REMOVE_SNACKBAR,
} from '../actionsTypes';
import { localStorageKeys } from '../../utils/const';

const { PC_MENU_DRAWER_EXPANDED: PC_MENU_DRAWER_EXPANDED_KEY } = localStorageKeys;

const storedPCMenuDrawerOpened = localStorage.getItem(PC_MENU_DRAWER_EXPANDED_KEY);
const initialState = {
  pcMenuDrawerOpened: storedPCMenuDrawerOpened !== 'false',
  mbMenuDrawerOpened: false,
  snackbars: [],
};

export default (state = initialState, action) => {
  const { type, payload } = action;
  switch (type) {
    case TOGGLE_PC_MENU_DRAWER:
      return {
        ...state,
        pcMenuDrawerOpened: payload,
      };
    case TOGGLE_MB_MENU_DRAWER:
      return {
        ...state,
        mbMenuDrawerOpened: payload,
      };
    case ENQUEUE_SNACKBAR:
      return {
        ...state,
        snackbars: [...state.snackbars, { ...payload }],
      };
    case CLOSE_SNACKBAR:
      return {
        ...state,
        snackbars: state.snackbars.map(sb =>
          !payload || sb.key === payload ? { ...sb, dismissed: true } : { ...sb }
        ),
      };
    case REMOVE_SNACKBAR:
      return {
        ...state,
        snackbars: state.snackbars.filter(sb => sb.key !== payload),
      };
    default:
      return state;
  }
};
