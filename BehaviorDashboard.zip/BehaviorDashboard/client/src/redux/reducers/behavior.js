import {
  FETCH_DAILY_COUNTS,
  FETCH_DAILY_COUNTS_SUCCESS,
  FETCH_DAILY_COUNTS_FAILURE,
  FETCH_EVENT_TYPE_COUNTS,
  FETCH_EVENT_TYPE_COUNTS_SUCCESS,
  FETCH_EVENT_TYPE_COUNTS_FAILURE,
  FETCH_TOP_BRANDS_COUNTS,
  FETCH_TOP_BRANDS_COUNTS_SUCCESS,
  FETCH_TOP_BRANDS_COUNTS_FAILURE,
} from '../actionsTypes';

const initialState = {
  dailyCountsLoading: false,
  dailyCounts: [],
  eventTypeCountsLoading: false,
  eventTypeCounts: [],
  topBrandsCountsLoading: false,
  topBrandsCounts: [],
};

export default (state = initialState, action) => {
  const { type, payload } = action;
  switch (type) {
    case FETCH_DAILY_COUNTS:
      return {
        ...state,
        dailyCountsLoading: true,
      };
    case FETCH_DAILY_COUNTS_SUCCESS:
      return {
        ...state,
        dailyCountsLoading: false,
        dailyCounts: [...payload],
      };
    case FETCH_DAILY_COUNTS_FAILURE:
      return {
        ...state,
        dailyCountsLoading: false,
      };
    case FETCH_EVENT_TYPE_COUNTS:
      return {
        ...state,
        eventTypeCountsLoading: true,
      };
    case FETCH_EVENT_TYPE_COUNTS_SUCCESS:
      return {
        ...state,
        eventTypeCountsLoading: false,
        eventTypeCounts: { ...payload },
      };
    case FETCH_EVENT_TYPE_COUNTS_FAILURE:
      return {
        ...state,
        eventTypeCountsLoading: false,
      };
    case FETCH_TOP_BRANDS_COUNTS:
      return {
        ...state,
        topBrandsCountsLoading: true,
      };
    case FETCH_TOP_BRANDS_COUNTS_SUCCESS:
      return {
        ...state,
        topBrandsCountsLoading: false,
        topBrandsCounts: [...payload],
      };
    case FETCH_TOP_BRANDS_COUNTS_FAILURE:
      return {
        ...state,
        topBrandsCountsLoading: false,
      };
    default:
      return state;
  }
};
