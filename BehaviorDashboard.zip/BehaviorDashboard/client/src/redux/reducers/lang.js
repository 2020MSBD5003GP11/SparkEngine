import { CHANGE_LANG } from '../actionsTypes';
import { localStorageKeys, defaultLang, supportedLang } from '../../utils/const';

const { LANG: KEY_LANG } = localStorageKeys;

let initialState = localStorage.getItem(KEY_LANG) || defaultLang;
if (!Object.values(supportedLang).includes(initialState)) {
  initialState = defaultLang;
}

export default (state = initialState, action) => {
  const { type, payload } = action;

  switch (type) {
    case CHANGE_LANG:
      if (Object.values(supportedLang).includes(payload)) {
        return payload;
      }
      return state;
    default:
      return state;
  }
};
