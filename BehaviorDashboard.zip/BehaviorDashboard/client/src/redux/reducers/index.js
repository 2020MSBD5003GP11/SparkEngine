import { combineReducers } from 'redux';
import ui from './ui';
import lang from './lang';
import behavior from './behavior';

export default combineReducers({ ui, lang, behavior });
