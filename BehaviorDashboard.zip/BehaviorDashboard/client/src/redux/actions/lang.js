import { CHANGE_LANG } from '../actionsTypes';

export const changeLang = lang => ({
  type: CHANGE_LANG,
  payload: lang,
});
