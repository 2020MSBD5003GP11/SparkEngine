import {
  FETCH_DAILY_COUNTS,
  FETCH_DAILY_COUNTS_SUCCESS,
  FETCH_DAILY_COUNTS_FAILURE,
  FETCH_EVENT_TYPE_COUNTS,
  FETCH_EVENT_TYPE_COUNTS_SUCCESS,
  FETCH_EVENT_TYPE_COUNTS_FAILURE,
  FETCH_TOP_BRANDS_COUNTS,
  FETCH_TOP_BRANDS_COUNTS_SUCCESS,
  FETCH_TOP_BRANDS_COUNTS_FAILURE,
} from '../actionsTypes';

export const fetchDailyCounts = (from, to) => ({
  type: FETCH_DAILY_COUNTS,
  payload: { from, to },
});
export const fetchDailyCountsSuccess = data => ({
  type: FETCH_DAILY_COUNTS_SUCCESS,
  payload: data,
});
export const fetchDailyCountsFailure = () => ({
  type: FETCH_DAILY_COUNTS_FAILURE,
});

export const fetchEventTypeCounts = (from, to) => ({
  type: FETCH_EVENT_TYPE_COUNTS,
  payload: { from, to },
});
export const fetchEventTypeCountsSuccess = data => ({
  type: FETCH_EVENT_TYPE_COUNTS_SUCCESS,
  payload: data,
});
export const fetchEventTypeCountsFailure = () => ({
  type: FETCH_EVENT_TYPE_COUNTS_FAILURE,
});

export const fetchTopBrandsCounts = (from, to) => ({
  type: FETCH_TOP_BRANDS_COUNTS,
  payload: { from, to },
});
export const fetchTopBrandsCountsSuccess = data => ({
  type: FETCH_TOP_BRANDS_COUNTS_SUCCESS,
  payload: data,
});
export const fetchTopBrandsCountsFailure = () => ({
  type: FETCH_TOP_BRANDS_COUNTS_FAILURE,
});
