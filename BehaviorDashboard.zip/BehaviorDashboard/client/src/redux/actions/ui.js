import {
  TOGGLE_PC_MENU_DRAWER,
  TOGGLE_MB_MENU_DRAWER,
  ENQUEUE_SNACKBAR,
  CLOSE_SNACKBAR,
  REMOVE_SNACKBAR,
} from '../actionsTypes';
import { v4 as uuidv4 } from 'uuid';

export const togglePCMenuDrawer = open => ({
  type: TOGGLE_PC_MENU_DRAWER,
  payload: open,
});

export const toggleMBMenuDrawer = open => ({
  type: TOGGLE_MB_MENU_DRAWER,
  payload: open,
});

const snackbarDefaultOptions = {
  variant: 'error',
  translate: true, // to translate the message
  // dismissed: false,
};
export const enqueueSnackbar = (message, msgArgs, options = {}, key) => ({
  type: ENQUEUE_SNACKBAR,
  payload: {
    message,
    msgArgs,
    options: {
      ...snackbarDefaultOptions,
      ...options,
    },
    key: key || uuidv4(),
  },
});

export const closeSnackbar = key => ({
  type: CLOSE_SNACKBAR,
  payload: key,
});

export const removeSnackbar = key => ({
  type: REMOVE_SNACKBAR,
  payload: key,
});
