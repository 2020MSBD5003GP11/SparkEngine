import { ajax } from 'rxjs/ajax';

const processUrlAndHeaders = (url, headers) => {
  return { url, headers };
};

export const getJSON = (url, headers) => {
  const processedUrlAndHeader = processUrlAndHeaders(url, headers);
  const { url: newUrl, headers: newHeaders } = processedUrlAndHeader;
  return ajax.getJSON(newUrl, newHeaders);
};

export const post = (url, body, headers) => {
  const processedUrlAndHeader = processUrlAndHeaders(url, {
    ...(headers || {}),
    'Content-Type': 'application/json',
  });
  const { url: newUrl, headers: newHeaders } = processedUrlAndHeader;
  return ajax.post(newUrl, body, newHeaders);
};
