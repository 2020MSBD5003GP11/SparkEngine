import { createStore, applyMiddleware } from 'redux';
import { createEpicMiddleware } from 'redux-observable';
import rootReducer from './reducers';
import rootEpic from './epics';
import { composeWithDevTools } from 'redux-devtools-extension';
import { getJSON, post } from './utils/ajax';
import translate from '../lang';
import { localStorageKeys } from '../utils/const';

const { LANG: KEY_LANG, PC_MENU_DRAWER_EXPANDED: PC_MENU_DRAWER_EXPANDED_KEY } = localStorageKeys;

const epicMiddleware = createEpicMiddleware({
  dependencies: { getJSON, post },
});
let enhancer = applyMiddleware(epicMiddleware);
if (process.env.NODE_ENV !== 'production') {
  enhancer = composeWithDevTools(enhancer);
}
const store = createStore(rootReducer, enhancer);

epicMiddleware.run(rootEpic);

// prevent obj parse error on first run of subscription
let currentState = { auth: { token: null }, ui: {} };
store.subscribe(() => {
  // keep track of the previous and current state to compare changes
  let previousState = currentState;
  currentState = store.getState();
  if (previousState.lang !== currentState.lang) {
    localStorage.setItem(KEY_LANG, currentState.lang);
    document.title = translate('PRODUCT_NAME', currentState.lang);
  }
  if (previousState.ui.pcMenuDrawerOpened !== currentState.ui.pcMenuDrawerOpened) {
    localStorage.setItem(PC_MENU_DRAWER_EXPANDED_KEY, currentState.ui.pcMenuDrawerOpened);
  }
});

export default store;
