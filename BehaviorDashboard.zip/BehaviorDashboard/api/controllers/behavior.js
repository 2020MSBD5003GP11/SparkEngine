const DailyCount = require('../../models/dailyCount');
const EventTypeCount = require('../../models/eventTypeCount');
const BrandCount = require('../../models/brandCount');
const { createResponseError: createError } = require('../utils/validation');
const responseJson = require('../utils/responseJson');

module.exports.getDailyTrend = async (req, res, next) => {
  try {
    const records = await DailyCount.find({
      day: {
        $gte: req.body.from,
        $lte: req.body.to,
      },
    })
      .select('-__v -_id')
      .sort('day')
      .lean();
    responseJson(records, req, res);
  } catch (err) {
    console.error('Failed to get daily trend: ' + err.message);
    return next(createError(500));
  }
};

module.exports.getEventTypeCounts = async (req, res, next) => {
  try {
    const records = await EventTypeCount.find({
      day: {
        $gte: req.body.from,
        $lte: req.body.to,
      },
    })
      .select('-__v -_id')
      .sort('day')
      .lean();
    const distinctEventTypes = await EventTypeCount.distinct('event_type');
    let ret = {};
    for (let event_type of distinctEventTypes) {
      ret[event_type] = records
        .filter(etc => etc.event_type === event_type)
        .reduce((sum, etc) => etc.count + sum, 0);
    }
    responseJson(ret, req, res);
  } catch (err) {
    console.error('Failed to get daily trend: ' + err.message);
    return next(createError(500));
  }
};

module.exports.getTopBrandsCounts = async (req, res, next) => {
  try {
    /* This is slow on Azure
    const records = await BrandCount.find({
      day: {
        $gte: req.body.from,
        $lte: req.body.to,
      },
      brand: {
        $ne: '',
      },
    })
      .select('-__v -_id')
      .sort('day')
      .lean();
    let brandCountMap = {};
    for (let record of records) {
      const { brand, count } = record;
      if (!brandCountMap[brand]) {
        brandCountMap[brand] = count;
      } else {
        brandCountMap[brand] += count;
      }
    }
    let ret = Object.entries(brandCountMap)
      .map(([brand, count]) => ({ brand, count }))
      .sort((a, b) => Math.sign(b.count - a.count))
      .filter((v, i) => i < 10);
    responseJson(ret, req, res);
    */
    const result = await BrandCount.aggregate([
      {
        $match: {
          day: {
            $gte: req.body.from,
            $lte: req.body.to,
          },
          brand: {
            $ne: '',
          },
        },
      },
      {
        $group: {
          _id: {
            brand: '$brand',
          },
          count: {
            $sum: '$count',
          },
        },
      },
      {
        $project: {
          count: '$count',
          brand: '$_id.brand',
          _id: false,
        },
      },
      {
        $sort: {
          count: -1,
        },
      },
      {
        $limit: 10,
      },
    ]);
    responseJson(result, req, res);
  } catch (err) {
    console.error('Failed to get daily trend: ' + err.message);
    return next(createError(500));
  }
};
