const mongoose = require('mongoose');
const createError = require('../../utils/createResponseError');

module.exports = Model => async (req, res, next) => {
  const { id } = req.params;
  if (!id) {
    return next(createError(400));
  }
  if (!mongoose.Types.ObjectId.isValid(id)) {
    return next(createError(400));
  }
  const record = await Model.findById(id);
  if (!record) {
    return next(createError(404));
  }
  req.recordFoundById = record;
  next();
};
