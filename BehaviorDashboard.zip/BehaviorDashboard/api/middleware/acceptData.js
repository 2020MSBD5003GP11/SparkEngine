module.exports.acceptPostData = fields => async (req, res, next) => {
  const data = {};
  fields.forEach(v => {
    if (req.body[v] !== undefined) {
      data[v] = req.body[v];
    }
  });
  req.acceptedPostData = data;
  next();
};
