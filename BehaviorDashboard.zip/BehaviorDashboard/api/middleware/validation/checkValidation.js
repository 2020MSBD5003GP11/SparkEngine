const { validationResult } = require('../../utils/validation');
const createError = require('../../utils/createResponseError');

module.exports = async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return next(createError(400, errors.array()));
  }
  next();
};
