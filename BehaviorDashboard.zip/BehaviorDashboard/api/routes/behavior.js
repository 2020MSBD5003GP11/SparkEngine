const express = require('express');
const router = express.Router();
const BehaviorController = require('../controllers/behavior');

// @route    GET api/behavior/get_daily_trend
// @desc     Get Daily Trend
// @access   Public
router.post('/get_daily_trend', BehaviorController.getDailyTrend);

// @route    GET api/behavior/get_event_type_counts
// @desc     Get Event Type Counts
// @access   Public
router.post('/get_event_type_counts', BehaviorController.getEventTypeCounts);

// @route    GET api/behavior/get_top_brands_counts
// @desc     Get Top Brand Counts
// @access   Public
router.post('/get_top_brands_counts', BehaviorController.getTopBrandsCounts);

module.exports = router;
