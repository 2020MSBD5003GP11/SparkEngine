module.exports.camelCaseToCapitalizedWithUnderScores = str =>
  str
    .replace(/([A-Z])/g, '_$1') // add _ before capital letter
    .replace(/__+/g, '_') // remove successive _
    .replace(/^_/, '') // remove initial _
    .toUpperCase();

module.exports.firstCharToUpper = str => str.charAt(0).toUpperCase() + str.slice(1);
