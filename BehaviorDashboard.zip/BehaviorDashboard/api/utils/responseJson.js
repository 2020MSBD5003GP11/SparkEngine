// add necessary data in res.json()

module.exports = (data, req, res) => {
  res.json({
    data,
  });
};
