const { getValidationMsg } = require('./validation');

let errMsgDef = {
  default: getValidationMsg('default', '', ''),
};
const definedStatuses = [400, 401, 404, 500];
for (status of definedStatuses) {
  errMsgDef[status] = getValidationMsg(`${status}`, '', '');
}

const createError = (status, data = null) => {
  if (data === null) {
    if (definedStatuses.includes(status)) {
      data = errMsgDef[status];
    } else {
      data = errMsgDef.default;
    }
  }
  const error = new Error();
  error.status = status;
  error.errors = Array.isArray(data)
    ? [...data]
    : [
        {
          message: `${data}`,
        },
      ];
  return error;
};

module.exports = createError;
