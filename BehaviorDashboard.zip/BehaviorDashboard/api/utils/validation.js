const { validationResult, check } = require('express-validator');
const { camelCaseToCapitalizedWithUnderScores } = require('./caseConversion');
const createError = require('./createResponseError');
const fs = require('fs');
const path = require('path');

const myValidationResult = validationResult.withDefaults({
  formatter: ({ msg, param }) => {
    return {
      message: msg,
      param,
    };
  },
});

let validationMsgs = [];
const writeValidationMsgsToTranslationKey = () => {
  try {
    const dirName = 'client/src/lang/def';
    const translationFiles = fs.readdirSync(dirName);
    for (let translationFile of translationFiles) {
      const fileName = path.join(dirName, translationFile);
      const stat = fs.lstatSync(fileName);
      if (!stat.isDirectory() && fileName.indexOf('.json') === fileName.length - '.json'.length) {
        const fileContent = `${fs.readFileSync(fileName)}`.trim();
        const fileLines = fileContent.split('\r\n');
        let emptyLines = {};
        fileLines.forEach((fileLine, lineIdx) => {
          if (fileLine.match(/^\s*$/)) {
            emptyLines[lineIdx] = fileLine;
          }
        });
        const jsonObj = JSON.parse(fileContent);
        // split into 2 obj with validation msgs and other msgs
        const nonValidationMsgsObj = Object.fromEntries(
          Object.entries(jsonObj).filter(([k, v]) => k.indexOf('RES_ERR_') !== 0)
        );
        let validationMsgsObj = Object.fromEntries(
          Object.entries(jsonObj).filter(([k, v]) => k.indexOf('RES_ERR_') === 0)
        );
        let assigned = false;
        for (let msg of validationMsgs) {
          const key = `RES_ERR_${msg}`;
          if (validationMsgsObj[key] === undefined) {
            validationMsgsObj[key] = '';
            assigned = true;
          }
        }
        if (assigned) {
          validationMsgsObj = Object.fromEntries(
            Object.entries(validationMsgsObj).sort((a, b) => (a[0] < b[0] ? -1 : 1))
          );
          let newFileLines = JSON.stringify(
            { ...nonValidationMsgsObj, ...validationMsgsObj },
            null,
            2
          ).split('\n');
          Object.entries(emptyLines).forEach(([lineIdx, lineContent]) => {
            newFileLines.splice(lineIdx, 0, lineContent);
          });
          fs.writeFileSync(fileName, newFileLines.join('\r\n'));
          console.log(`translation definition generated for ${translationFile}`);
        }
      }
    }
  } catch (err) {
    console.log(err);
  }
};
if (process.env.NODE_ENV !== 'production') {
  setTimeout(writeValidationMsgsToTranslationKey, 1000); // write to translation definition after 1 second
}

// getValidationMsg('model', 'subMsg', 'VALIDATION') => 'MODEL_VALIDATION_SUB_MSG'
const getValidationMsg = (modelName, subMsgInCamelCase, validationNameInUpper = 'VALIDATION') => {
  const generatedMsg = [
    camelCaseToCapitalizedWithUnderScores(modelName),
    validationNameInUpper,
    camelCaseToCapitalizedWithUnderScores(subMsgInCamelCase),
  ]
    .filter(v => v !== '')
    .join('_');
  validationMsgs.push(generatedMsg);
  return generatedMsg;
};

const validationCheck = (modelName, fieldName, validationSubMsg = fieldName) =>
  check(fieldName, `${getValidationMsg(modelName, validationSubMsg)}`);

const checkRequiredFieldsDefined = (modelName, requiredFields) => {
  let validationMsgDef = {};
  for (let field of requiredFields) {
    validationMsgDef[field] = getValidationMsg(modelName, field, 'VALIDATION_REQUIRED');
  }
  return (req, res, next) => {
    for (let field of requiredFields) {
      if (req.body[field] === undefined) {
        return next(createError(400, validationMsgDef[field]));
      }
    }
    next();
  };
};

const createValidationError = (
  modelName,
  subMsgInCamelCase,
  validationNameInUpper = 'VALIDATION'
) => {
  return new Error(getValidationMsg(modelName, subMsgInCamelCase, validationNameInUpper));
};

module.exports = {
  validationResult: myValidationResult,
  getValidationMsg,
  validationCheck,
  checkRequiredFieldsDefined,
  createValidationError,
};
