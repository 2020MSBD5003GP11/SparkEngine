const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const BehaviorSchema = new Schema({
  event_time: {
    type: Date,
    index: true,
  },
  event_type: {
    type: String,
    index: true,
  },
  product_id: {
    type: String,
  },
  category_id: {
    type: String,
  },
  category_code: {
    type: String,
  },
  brand: {
    type: String,
    index: true,
  },
  price: {
    type: Number,
  },
  user_id: {
    type: String,
  },
  user_session: {
    type: String,
  },
});

module.exports = mongoose.model('behaviorData', BehaviorSchema, 'BehaviorData');
