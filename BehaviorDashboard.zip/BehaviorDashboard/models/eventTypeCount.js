const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const EventTypeCountSchema = new Schema({
  day: {
    type: String,
  },
  event_type: {
    type: String,
  },
  count: {
    type: Number,
  },
});

module.exports = mongoose.model('eventTypeCount', EventTypeCountSchema);
