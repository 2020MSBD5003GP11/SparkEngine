const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const BrandCountSchema = new Schema({
  day: {
    type: String,
  },
  brand: {
    type: String,
  },
  count: {
    type: Number,
  },
});

module.exports = mongoose.model('brandCount', BrandCountSchema);
