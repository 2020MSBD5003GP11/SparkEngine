const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const DailyCountSchema = new Schema({
  day: {
    type: String,
    unique: true,
  },
  count: {
    type: Number,
  },
});

module.exports = mongoose.model('dailyCount', DailyCountSchema);
