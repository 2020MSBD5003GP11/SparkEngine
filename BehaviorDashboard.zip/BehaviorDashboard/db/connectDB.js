const mongoose = require('mongoose');
const config = require('config');
const connectionString = config.get('mongoURI');
const updateData = require('./updateData');

let conn = null;
const connectDB = async () => {
  if (!connectionString) {
    console.error(
      '\x1b[44;33m%s\x1b[0m',
      'Please first define the MongoDB connection string in config'
    );
    process.exit(1);
  }
  try {
    conn = await mongoose.connect(connectionString, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      useCreateIndex: true,
      useFindAndModify: false,
    });
    console.log('MongoDB Connected');

    await updateData(conn);
    console.log('DB Records updated');
  } catch (err) {
    console.error(err.message);
    // Exit process with failure
    process.exit(1);
  }
};
module.exports = connectDB;
