const DailyCount = require('../models/dailyCount');
const EventTypeCount = require('../models/eventTypeCount');
const BrandCount = require('../models/brandCount');
const Behavior = require('../models/behavior');
const moment = require('moment');

const updateDailyCount = false;
const updateEventTypeCount = false;
const updateBrandCount = false;

module.exports = async conn => {
  if (updateDailyCount) {
    try {
      let promises = [];
      let counts = [];
      let dateItr = moment('2019-10-01');
      while (dateItr.isBefore('2019-11-01')) {
        const from = moment(dateItr).format('YYYY-MM-DD');
        const to = moment(dateItr).add(1, 'd').format('YYYY-MM-DD');
        promises.push(async () => {
          const count = await Behavior.countDocuments({
            event_time: {
              $gte: from,
              $lt: to,
            },
          });
          counts.push({ count, day: from });
        });
        dateItr.add(1, 'd');
      }
      await Promise.all(promises.map(p => p()));
      counts = counts.sort((a, b) => (a.day < b.day ? -1 : a.day > b.day ? 1 : 0));
      for (let dc of counts) {
        const { day, count } = dc;
        const found = await DailyCount.findOneAndUpdate({ day }, { $set: { count } });
        if (!found) {
          const newEntry = new DailyCount({ day, count });
          await newEntry.save();
        }
      }
    } catch (err) {
      console.error(err.message);
    }
  }

  if (updateEventTypeCount) {
    const distinctEventTypes = await Behavior.distinct('event_type');
    try {
      let promises = [];
      let counts = [];
      let dateItr = moment('2019-10-01');
      while (dateItr.isBefore('2019-11-01')) {
        const from = moment(dateItr).format('YYYY-MM-DD');
        const to = moment(dateItr).add(1, 'd').format('YYYY-MM-DD');
        for (let event_type of distinctEventTypes) {
          promises.push(async () => {
            const count = await Behavior.countDocuments({
              event_time: {
                $gte: from,
                $lt: to,
              },
              event_type,
            });
            counts.push({ count, day: from, event_type });
          });
        }
        dateItr.add(1, 'd');
      }
      await Promise.all(promises.map(p => p()));
      counts = counts.sort((a, b) =>
        a.day < b.day
          ? -1
          : a.day > b.day
          ? 1
          : a.event_type < b.event_type
          ? -1
          : a.event_type > b.event_type
          ? 1
          : 0
      );
      for (let etc of counts) {
        const { day, event_type, count } = etc;
        const found = await EventTypeCount.findOneAndUpdate(
          { day, event_type },
          { $set: { count } }
        );
        if (!found) {
          const newEntry = new EventTypeCount({ day, event_type, count });
          await newEntry.save();
        }
      }
    } catch (err) {
      console.error(err.message);
    }
  }

  if (updateBrandCount) {
    try {
      let n = 0;
      let brandMap = {};
      let nNewEntries = 0;
      await Behavior.find()
        .select({ brand: 1, event_time: 1 })
        .lean()
        .cursor()
        .eachAsync(
          behavior => {
            n++;
            const event_time = behavior.event_time.toISOString().split('T')[0]; //moment.utc(behavior.event_time).format('YYYY-MM-DD');
            const { brand } = behavior;
            if (!brandMap[event_time]) {
              brandMap[event_time] = {};
            }
            if (!brandMap[event_time][brand]) {
              brandMap[event_time][brand] = 0;
              nNewEntries++;
            }
            brandMap[event_time][brand]++;
            if (n % 10000 === 1) {
              console.log(n);
            }
          },
          { parallel: 1000 }
        );
      console.log(`loop all ${n} behaviors success`);
      let saved = 0;
      for (let [day, brandCounts] of Object.entries(brandMap)) {
        for (let [brand, count] of Object.entries(brandCounts)) {
          const newEntry = new BrandCount({ day, brand, count });
          await newEntry.save();
          saved++;
          console.log(`${saved} / ${nNewEntries} saved`);
        }
      }
    } catch (err) {
      console.error(err.message);
    }
  }
};
